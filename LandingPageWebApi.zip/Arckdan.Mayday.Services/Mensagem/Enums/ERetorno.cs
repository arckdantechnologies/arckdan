﻿namespace Arckdan.Mayday.Services.Mensagem.Enums
{
    public enum ERetorno
    {
        #region códigos

        Sucesso = 0,
        Alerta = 1,
        Erro = 2

        #endregion
    }
}
