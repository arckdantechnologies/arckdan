﻿namespace Arckdan.Mayday.Services.Mensagem.Enums
{
    public enum EValidacao
    {
        Usuario = 1,
        Token = 2,
        Email = 3,
        Cadastro  = 4,
        Atualizacao = 5
    }
}
